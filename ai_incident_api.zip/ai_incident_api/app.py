from flask import Flask, request, jsonify
from database import db
from models import Incident
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///incidents.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create DB
with app.app_context():
    db.create_all()

@app.route('/incidents', methods=['GET'])
def get_incidents():
    incidents = Incident.query.all()
    return jsonify([
        {
            'id': i.id,
            'title': i.title,
            'description': i.description,
            'severity': i.severity,
            'reported_at': i.reported_at.isoformat()
        } for i in incidents
    ]), 200

@app.route('/incidents', methods=['POST'])
def create_incident():
    data = request.get_json()
    if not all(k in data for k in ('title', 'description', 'severity')):
        return jsonify({'error': 'Missing fields'}), 400

    if data['severity'] not in ['Low', 'Medium', 'High']:
        return jsonify({'error': 'Invalid severity value'}), 400

    new_incident = Incident(
        title=data['title'],
        description=data['description'],
        severity=data['severity']
    )
    db.session.add(new_incident)
    db.session.commit()
    return jsonify({
        'id': new_incident.id,
        'title': new_incident.title,
        'description': new_incident.description,
        'severity': new_incident.severity,
        'reported_at': new_incident.reported_at.isoformat()
    }), 201

@app.route('/incidents/<int:incident_id>', methods=['GET'])
def get_incident(incident_id):
    incident = Incident.query.get(incident_id)
    if not incident:
        return jsonify({'error': 'Incident not found'}), 404

    return jsonify({
        'id': incident.id,
        'title': incident.title,
        'description': incident.description,
        'severity': incident.severity,
        'reported_at': incident.reported_at.isoformat()
    }), 200

@app.route('/incidents/<int:incident_id>', methods=['DELETE'])
def delete_incident(incident_id):
    incident = Incident.query.get(incident_id)
    if not incident:
        return jsonify({'error': 'Incident not found'}), 404

    db.session.delete(incident)
    db.session.commit()
    return jsonify({'message': 'Incident deleted'}), 200

if __name__ == '__main__':
    app.run(debug=True)
