from app import db, Incident

sample_incidents = [
    Incident(title='AI system failed to detect hate speech', description='Example failure case in moderation AI.', severity='High'),
    Incident(title='Incorrect medical advice from AI assistant', description='A chatbot gave wrong prescription.', severity='Medium')
]

with db.session.begin():
    db.session.add_all(sample_incidents)

print("Sample incidents added.")
